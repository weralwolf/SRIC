<?php $this->pageTitle=Yii::app()->name; ?>

<h1>Welcome to <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>

<p>Check the following EFgMenu-related codes:</p>
<ul>
	<li>/protected/extensions/efgmenu/</li>
	<li>/protected/views/layouts/main.php</li>
</ul>
